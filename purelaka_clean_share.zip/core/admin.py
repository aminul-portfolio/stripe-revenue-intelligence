from django.contrib import admin

admin.site.site_header = "PureLaka Commerce Platform"
admin.site.site_title = "PureLaka Admin"
admin.site.index_title = "Operations Console"
